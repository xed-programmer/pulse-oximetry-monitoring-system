<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>POMS</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  

  <!-- Google Fonts -->
  <link
    href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
    rel="stylesheet">
  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('BizLand/assets/vendor/aos/aos.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('BizLand/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('BizLand/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('BizLand/assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('BizLand/assets/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('BizLand/assets/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('plugins/toastr/toastr.min.css')); ?>">

  <?php echo $__env->yieldPushContent('links'); ?>
  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('BizLand/assets/css/style.css')); ?>" rel="stylesheet">

</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a
            href="mailto:xedprogrammer@gmail.com">xedprogrammer@gmail.com</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span>09510592362</span></i>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <!-- Uncomment below if you prefer to use an image logo -->
      <div class="d-flex flex-row align-items-center">
        <a href="index.html" class="logo"><img src="<?php echo e(asset('dist/img/logo.png')); ?>" alt="POMS"></a>
        <h1 class="logo"><a href="<?php echo e(route('home')); ?>">POMS<span>.</span></a></h1>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link active" href="<?php echo e(route('home')); ?>">Home</a></li>
          <li><a class="nav-link" href="<?php echo e(route('home')); ?>#about">About</a></li>
          <li><a class="nav-link" href="<?php echo e(route('home')); ?>#contact">Contact</a></li>
          <?php if(auth()->guard()->check()): ?>
          <?php if(auth()->user()->hasRole('user')): ?>
          <li>
            <a href="<?php echo e(route('user.index')); ?>" class="nav-link">User</a>
          </li>
          <?php endif; ?>
          <li class="dropdown"><a href="#"><span><?php echo e(Str::limit(Auth::user()->name,15)); ?></span></a>
            <ul>
              <li><a href="#">
                 <p>Your Profile
                  <br>
                <?php echo e(Str::limit(Auth::user()->email, 22)); ?></a></li>
                 </p>
              <li>
                <form action="<?php echo e(route('logout')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <input type="submit" value="Logout" class="btn btn-light btn-block">
                </form>
              </li>
            </ul>
          </li>

          <?php else: ?>
          <li>
            <a href="<?php echo e(route('login')); ?>" class="nav-link">Login</a>
          </li>
          <li>
            <a href="<?php echo e(route('register')); ?>" class="nav-link">Register</a>
          </li>
          <?php endif; ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <?php echo $__env->yieldContent('header'); ?>

  <main id="main" data-aos="fade-up">
    <?php echo $__env->yieldContent('content'); ?>
  </main>
  <?php echo $__env->yieldContent('modals'); ?>


  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
  

  
  <script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('BizLand/assets/vendor/aos/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('BizLand/assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('BizLand/assets/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('BizLand/assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('BizLand/assets/vendor/waypoints/noframework.waypoints.js')); ?>"></script>
  <script src="<?php echo e(asset('BizLand/assets/vendor/php-email-form/validate.js')); ?>"></script>
  <?php if (isset($component)) { $__componentOriginal24a7f3fab743592df499c1f040f6dd44c47bc097 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ToastrScripts::class, []); ?>
<?php $component->withName('toastr-scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal24a7f3fab743592df499c1f040f6dd44c47bc097)): ?>
<?php $component = $__componentOriginal24a7f3fab743592df499c1f040f6dd44c47bc097; ?>
<?php unset($__componentOriginal24a7f3fab743592df499c1f040f6dd44c47bc097); ?>
<?php endif; ?>
  <?php echo $__env->yieldPushContent('scripts'); ?>
  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('BizLand/assets/js/main.js')); ?>"></script>

</body>

</html><?php /**PATH C:\Users\XED\LaravelProject\pulse-oximetry-monitoring-system\resources\views/layouts/app.blade.php ENDPATH**/ ?>