<script src="<?php echo e(asset('plugins/toastr/toastr.min.js')); ?>"></script>
<?php if(session()->has('message')): ?>
    <?php if(session()->get('result') == "success"): ?>
        <script>
            toastr.success("<?php echo e(session()->get('message')); ?>")
        </script>
    <?php else: ?>
        <script>
            toastr.error("<?php echo e(session()->get('message')); ?>")
        </script>
    <?php endif; ?>
<?php endif; ?><?php /**PATH C:\Users\XED\LaravelProject\pulse-oximetry-monitoring-system\resources\views/components/toastr-scripts.blade.php ENDPATH**/ ?>