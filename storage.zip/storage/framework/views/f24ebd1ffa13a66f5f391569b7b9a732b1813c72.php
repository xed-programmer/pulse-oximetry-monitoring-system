<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Pulse Report</title>
</head>
<body>
<h1>Pulse Report</h1>
<h2><?php echo e($details->user->created_at->format('M d, Y h:m:s A')); ?></h2>
<table>
<tr>
<td><p><strong><?php echo e($details->hr); ?></strong> <span>bpm</span></p></td>
</tr>
<tr>
<td><p>SPO2 <strong><?php echo e($details->spo2); ?></strong>%</p></td>
</tr>
</table>

<p>
Patient's heart rate is <?php echo e($details->hr); ?>

</p> <br>
<p>
Patient's oxygen saturation level is         
<?php if($details->spo2 < $details->spo2_limit): ?>
below <?php echo e($details->spo2_limit); ?>%.
The patient should visit a doctor immediately.
<?php else: ?>
<?php echo e($details->spo2); ?>

<?php endif; ?>
</p> <br>

Truly,<br>
<?php echo e(config('app.name')); ?>

</body>
</html><?php /**PATH C:\Users\XED\LaravelProject\pulse-oximetry-monitoring-system\resources\views/emails/pulse-report.blade.php ENDPATH**/ ?>